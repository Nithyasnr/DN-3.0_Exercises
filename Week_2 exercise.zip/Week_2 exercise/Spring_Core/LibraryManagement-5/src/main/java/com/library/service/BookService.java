package com.library.service;

import org.springframework.stereotype.Service;

import com.library.Repository.BookRepository;
@Service
public class BookService {
	BookRepository book;

	public BookRepository getBook() {
		return book;
	}

	public void setBook(BookRepository book) {
		this.book = book;
	}
	
}
