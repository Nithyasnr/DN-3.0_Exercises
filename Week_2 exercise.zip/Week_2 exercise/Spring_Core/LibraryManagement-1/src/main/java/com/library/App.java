package com.library;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        // Load Spring context from XML configuration
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();

        // Retrieve the Library bean from the context
        Library obj = (Library) context.getBean("libraryBean");

        // Call a method on the Library bean
        obj.read();
    }
}

