package com.library.service;

import com.library.Library;

public class BookService implements Library {
	
	public void read() {
		System.out.println("reading");
	}

}
