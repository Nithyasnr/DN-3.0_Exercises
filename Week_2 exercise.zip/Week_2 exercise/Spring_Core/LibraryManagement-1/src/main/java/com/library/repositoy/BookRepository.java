package com.library.repositoy;

import com.library.Library;

public class BookRepository  implements Library{
	
	public void read() {
		System.out.println("we have book stored");
	}

}
