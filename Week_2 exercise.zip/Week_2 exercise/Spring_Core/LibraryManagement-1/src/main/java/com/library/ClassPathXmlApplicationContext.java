package com.library;

import org.springframework.context.ApplicationContext;

public class ClassPathXmlApplicationContext extends ApplicationContext {

}
