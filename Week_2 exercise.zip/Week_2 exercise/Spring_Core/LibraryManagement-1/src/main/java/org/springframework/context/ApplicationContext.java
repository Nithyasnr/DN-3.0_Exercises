package org.springframework.context;

import com.library.Library;

public class ApplicationContext {

	public Library getBean(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
