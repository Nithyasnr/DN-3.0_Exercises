package org.springframework.context.support;

import com.library.Library;

public class ClassPathXmlApplicationContext {

	public Library getBean(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
