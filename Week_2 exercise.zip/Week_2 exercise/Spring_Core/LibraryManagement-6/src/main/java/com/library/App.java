package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library.Repository.BookRepository;
import com.library.service.BookService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");

         BookService bookService = (BookService) context.getBean("bookService");
         //bookService.add(new BookRepository(1,"Origins","Dan Brown"));
         //bookService.add(new BookRepository(2,"A good girls guide to murder","Holly Jackson"));
         //bookService.add(new BookRepository(3,"The Da Vinci code","Dan Brown"));
         //bookService.add(new BookRepository(4,"It End's with You","Collon Hover"));
         BookRepository book=(BookRepository)context.getBean("bookRepository");
         System.out.println(book);
         
         //bookService.print();
    }
}
