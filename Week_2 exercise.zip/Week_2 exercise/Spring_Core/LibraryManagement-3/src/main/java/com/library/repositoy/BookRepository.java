package com.library.repositoy;

import com.library.Book;
import java.util.ArrayList;
import java.util.List;


public class BookRepository{
	
    private List<Book> bookDatabase = new ArrayList<>();

   
    public void save(Book book) {
        bookDatabase.add(book);
        System.out.println("Book saved: " + book);
    }

    
    public List<Book> findAll() {
        return new ArrayList<>(bookDatabase);
    }

    
    public Book findByIsbn(String isbn) {
        for (Book book : bookDatabase) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

}
