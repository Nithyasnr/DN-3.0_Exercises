package com.library.service;

import com.library.library;

public class BookService implements library {
    public void read(){
        System.out.println("I am reading this book");
    }
}
