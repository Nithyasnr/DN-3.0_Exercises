package com.library.repository;

import com.library.library;

public class BookRepository implements library {
    public void read(){
        System.out.println("this is the book called sherlock homes");
    }
}
