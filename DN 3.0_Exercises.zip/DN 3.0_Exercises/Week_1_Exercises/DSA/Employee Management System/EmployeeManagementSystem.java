import java.util.Arrays;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size >= employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[size++] = employee;
    }

    // Search for an employee by ID
    public Employee searchEmployee(String employeeId) {
        for (Employee employee : employees) {
            if (employee != null && employee.getEmployeeId().equals(employeeId)) {
                return employee;
            }
        }
        return null; // Not found
    }

    // Traverse all employees
    public void traverseEmployees() {
        for (Employee employee : employees) {
            if (employee != null) {
                System.out.println(employee);
            }
        }
    }

    // Delete an employee by ID
    public boolean deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                employees[i] = employees[size - 1]; // Replace with last element
                employees[size - 1] = null; // Remove last element
                size--;
                return true;
            }
        }
        return false; // Not found
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(3);

        // Adding employees
        ems.addEmployee(new Employee("E001", "Alice", "Manager", 60000));
        ems.addEmployee(new Employee("E002", "Bob", "Developer", 50000));
        ems.addEmployee(new Employee("E003", "Charlie", "Designer", 45000));

        // Searching for an employee
        Employee foundEmployee = ems.searchEmployee("E002");
        System.out.println("Search Result: " + foundEmployee);

        // Traversing employees
        System.out.println("All Employees:");
        ems.traverseEmployees();

        // Deleting an employee
        boolean isDeleted = ems.deleteEmployee("E003");
        System.out.println("Delete Result: " + isDeleted);

        // Traversing after deletion
        System.out.println("Employees after deletion:");
        ems.traverseEmployees();
    }
}

