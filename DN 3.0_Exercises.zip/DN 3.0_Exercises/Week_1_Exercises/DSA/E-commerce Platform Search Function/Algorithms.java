import java.util.Arrays;
public class Algorithms {

    // Linear search implementation
    public static Product linearSearch(Product[] products, String searchId) {
        for (Product product : products) {
            if (product.getProductId().equals(searchId)) {
                return product;
            }
        }
        return null; // Not found
    }

    // Binary search implementation (array must be sorted by productId)
    public static Product binarySearch(Product[] products, String searchId) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId().equals(searchId)) {
                return products[mid];
            }
            if (products[mid].getProductId().compareTo(searchId) < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Not found
    }

    public static void main(String[] args) {
        // Example products
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Mouse", "Electronics"),
            new Product("P003", "Chair", "Furniture")
        };

        Product foundProduct = linearSearch(products, "P002");
        System.out.println("Linear Search Result: " + foundProduct);

        // Sorting the array by productId for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        // Binary Search Example
        foundProduct = binarySearch(products, "P003");
        System.out.println("Binary Search Result: " + foundProduct);
    }
}
