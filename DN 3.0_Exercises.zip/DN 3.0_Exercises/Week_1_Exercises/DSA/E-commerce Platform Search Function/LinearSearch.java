public class LinearSearch {
    public static Product linearSearch(Product[] products, int target) {
        for (Product product : products) {
            if (product.getProductId() == target) {
                return product;
            }
        }
        return null;
    }
}


