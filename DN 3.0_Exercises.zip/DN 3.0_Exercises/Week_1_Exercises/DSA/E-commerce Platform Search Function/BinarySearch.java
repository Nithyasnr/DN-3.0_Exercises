import java.util.Arrays;
import java.util.Comparator;

public class BinarySearch {
    public static Product binarySearch(Product[] products, int target) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (products[mid].getProductId() == target) {
                return products[mid];
            } else if (products[mid].getProductId() < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Book", "Books"),
            new Product(4, "Shoes", "Apparel"),
            new Product(5, "Watch", "Accessories")
        };

        // Sort products by productId for binary search
        Arrays.sort(products, Comparator.comparingInt(Product::getProductId));

        // Example usage of linear search
        Product resultLinear = LinearSearch.linearSearch(products, 3);
        System.out.println("Linear Search Result: " + resultLinear);

        // Example usage of binary search
        Product resultBinary = binarySearch(products, 3);
        System.out.println("Binary Search Result: " + resultBinary);
    }
}
