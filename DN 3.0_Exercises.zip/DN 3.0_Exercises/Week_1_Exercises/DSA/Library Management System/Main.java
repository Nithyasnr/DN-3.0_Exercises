public class Main {
    public static void main(String[] args) {
        LibraryManagementSystem system = new LibraryManagementSystem(10);

        // Adding books
        system.addBook(new Book("B001", "Nightingale", "Leo"));
        system.addBook(new Book("B002", "1947", "Dyer"));
        system.addBook(new Book("B003", "The Big Bang Theory", "Panlo Coehlo"));

        // Linear search
        Book foundBook = system.linearSearchByTitle("Nightingale");
        if (foundBook != null) {
            System.out.println("Book Found (Linear Search): " + foundBook);
        } else {
            System.out.println("Book not found (Linear Search).");
        }

        // Binary search (assuming books are sorted by title)
        foundBook = system.binarySearchByTitle("1947");
        if (foundBook != null) {
            System.out.println("Book Found (Binary Search): " + foundBook);
        } else {
            System.out.println("Book not found (Binary Search).");
        }
    }
}

