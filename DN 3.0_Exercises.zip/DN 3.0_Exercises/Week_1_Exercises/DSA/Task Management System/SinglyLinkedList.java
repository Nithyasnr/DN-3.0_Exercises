public class SinglyLinkedList {
    private class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    private Node head;

    public SinglyLinkedList() {
        this.head = null;
    }

    // Add a task to the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by ID
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null; // Not found
    }

    // Traverse all tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by ID
    public boolean deleteTask(String taskId) {
        if (head == null) {
            return false;
        }

        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            return true;
        }

        Node current = head;
        while (current.next != null && !current.next.task.getTaskId().equals(taskId)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
            return true;
        }

        return false; // Not found
    }

    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        // Adding tasks
        taskList.addTask(new Task("T001", "Design UI", "In Progress"));
        taskList.addTask(new Task("T002", "Implement Backend", "Not Started"));
        taskList.addTask(new Task("T003", "Write Tests", "In Progress"));

        // Searching for a task
        Task foundTask = taskList.searchTask("T002");
        System.out.println("Search Result: " + foundTask);

        // Traversing tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Deleting a task
        boolean isDeleted = taskList.deleteTask("T003");
        System.out.println("Delete Result: " + isDeleted);

        // Traversing after deletion
        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
    }
}
