
public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        
        Customer customer = new Customer();
        customer.setId(id);
        customer.setName("John Doe");
        return customer;
    }
}
