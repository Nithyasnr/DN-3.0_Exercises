public class Square {
    public void doPayment(double amount) {
        System.out.println("Payment of $" + amount + " made using Square.");
    }
}